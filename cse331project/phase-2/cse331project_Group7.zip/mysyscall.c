#include <linux/mysyscall.h>
#include <linux/kernel.h>
#include <asm/uaccess.h>

extern int xyZeren;
extern int howmanyuser;
asmlinkage int sys_mysyscall(int arg1,int *arg2){
xyZeren=arg1;
int a;
int i=0;
cli();
copy_from_user(&a,arg2,sizeof(int));

a=howmanyuser;
copy_to_user(arg2,&a,sizeof(int));
sti();


return 0;

}
