#include <linux/mysyscall.h>
#include<unistd.h>
main(){
int a;
mysyscall(0,&a);
printf("%d\n",a);
return;
}
