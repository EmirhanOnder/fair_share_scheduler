#ifndef __LINUX_MYSYSCALL_H
#define __LINUX_MYSYSCALL_H
#include <linux/linkage.h>
#endif